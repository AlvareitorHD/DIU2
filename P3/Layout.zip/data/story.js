var story = {
 "docName": "Wireframes",
 "docPath": "P_P_P",
 "docVersion": 100000001,
 "ownerName": "",
 "ownerEmail": "",
 "authorName": "V_V_N",
 "authorEmail": "V_V_E",
 "fileType": "jpg",
 "disableInteractions": false,
 "highlightHotspot": true,
 "highlightAllHotspots": true,
 "hideGallery": false,
 "galleryPageColorsEnabled": true,
 "galleryDecorNodesEnabled": true,
 "zoomEnabled": true,
 "cloud": false,
 "title": "Wireframes",
 "layersExist": true,
 "pages": [
  {
   "id": "1:2",
   "groupIndex": 0,
   "title": "Inicio",
   "image": "inicio.jpg",
   "index": 0,
   "width": 1338,
   "height": 774,
   "x": -619,
   "y": -262,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "9:74",
   "groupIndex": 0,
   "title": "Recetas",
   "image": "recetas.jpg",
   "index": 1,
   "width": 1338,
   "height": 774,
   "x": -619,
   "y": 572,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "39:26",
   "groupIndex": 0,
   "title": "Landing Page",
   "image": "landing-page.jpg",
   "index": 2,
   "width": 2664,
   "height": 2298,
   "x": 727,
   "y": 1897,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "8:2",
   "groupIndex": 0,
   "title": "FAQ",
   "image": "faq.jpg",
   "index": 3,
   "width": 1338,
   "height": 774,
   "x": 759,
   "y": -262,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "16:41",
   "groupIndex": 0,
   "title": "Cursos",
   "image": "cursos.jpg",
   "index": 4,
   "width": 1338,
   "height": 774,
   "x": 759,
   "y": 572,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "16:233",
   "groupIndex": 0,
   "title": "Cuenta",
   "image": "cuenta.jpg",
   "index": 5,
   "width": 1338,
   "height": 774,
   "x": 2137,
   "y": -262,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "16:376",
   "groupIndex": 0,
   "title": "Ayuda",
   "image": "ayuda.jpg",
   "index": 6,
   "width": 1338,
   "height": 774,
   "x": 2137,
   "y": 572,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "56:14",
   "groupIndex": 0,
   "title": "imagen 4",
   "image": "imagen-4.jpg",
   "index": 7,
   "width": 1349.864990234375,
   "height": 297,
   "x": 3795,
   "y": 2749,
   "isFrame": false,
   "type": "item",
   "fixedPanels": [],
   "links": []
  },
  {
   "id": "82:129",
   "groupIndex": 1,
   "title": "SPLAH",
   "image": "splah.jpg",
   "index": 8,
   "width": 270,
   "height": 591,
   "x": 2280,
   "y": 117,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "SPLAH",
     "rect": {
      "x": 0,
      "y": 0,
      "width": 270,
      "height": 591
     },
     "index": 0,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "AFTER_TIMEOUT",
       "triggerTimeout": 800,
       "srcPageIndex": 8,
       "frameIndex": 9,
       "transAnimType": 0,
       "transAnimDuration": 0.5
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "72:30",
   "groupIndex": 1,
   "title": "INICIO SESION",
   "image": "inicio-sesion.jpg",
   "index": 9,
   "width": 270,
   "height": 591,
   "x": 2820,
   "y": -179,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 1,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 146,
      "y": 310,
      "width": 84,
      "height": 40
     },
     "index": 2,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 91,
      "y": 491,
      "width": 84,
      "height": 32
     },
     "index": 3,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 10,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "129:860",
   "groupIndex": 1,
   "title": "REGISTRARSE",
   "image": "registrarse.jpg",
   "index": 10,
   "width": 270,
   "height": 591,
   "x": 2820,
   "y": 520,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 4,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 10,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 67,
      "y": 484,
      "width": 117,
      "height": 49
     },
     "index": 5,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 10,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "82:3024",
   "groupIndex": 1,
   "title": "INICIO",
   "image": "inicio.jpg",
   "index": 11,
   "width": 270,
   "height": 591,
   "x": 3231,
   "y": -178,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "curso",
     "rect": {
      "x": 11,
      "y": 441,
      "width": 246,
      "height": 328
     },
     "index": 6,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 11,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 7,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 11,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 8,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 11,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 9,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 11,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Horizontal card",
     "rect": {
      "x": 9,
      "y": 368,
      "width": 244,
      "height": 61
     },
     "index": 10,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 11,
       "frameIndex": 18,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "120:5953",
   "groupIndex": 1,
   "title": "CURSOS",
   "image": "cursos.jpg",
   "index": 12,
   "width": 270,
   "height": 591,
   "x": 3232,
   "y": 2202,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 11,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 12,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 12,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 12,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 13,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 12,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 11,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 14,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 12,
       "frameIndex": 14,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 144,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 15,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 12,
       "frameIndex": 23,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "104:548",
   "groupIndex": 1,
   "title": "RECETAS",
   "image": "recetas.jpg",
   "index": 13,
   "width": 270,
   "height": 591,
   "x": 3315,
   "y": 839,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 16,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 13,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 17,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 13,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 18,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 13,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Group 7",
     "rect": {
      "x": 9,
      "y": 209,
      "width": 244,
      "height": 61
     },
     "index": 19,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 13,
       "frameIndex": 18,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "explora",
     "rect": {
      "x": 11,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 20,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 13,
       "frameIndex": 15,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "guardadas",
     "rect": {
      "x": 144,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 21,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 13,
       "frameIndex": 20,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "126:723",
   "groupIndex": 1,
   "title": "CURSOS-BUSCAR",
   "image": "cursos-buscar.jpg",
   "index": 14,
   "width": 270,
   "height": 591,
   "x": 3542,
   "y": 2202,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 22,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 14,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 23,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 14,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 24,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 14,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 25,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 14,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 144,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 26,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 14,
       "frameIndex": 23,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Suggestion chip",
     "rect": {
      "x": 14,
      "y": 277,
      "width": 58,
      "height": 32
     },
     "index": 27,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 14,
       "frameIndex": 19,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "104:971",
   "groupIndex": 1,
   "title": "RECETAS-BUSCAR",
   "image": "recetas-buscar.jpg",
   "index": 15,
   "width": 270,
   "height": 591,
   "x": 3625,
   "y": 839,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 28,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 15,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 29,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 15,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 30,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 15,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Group 7",
     "rect": {
      "x": 9,
      "y": 351,
      "width": 244,
      "height": 61
     },
     "index": 31,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 15,
       "frameIndex": 18,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "guardadas",
     "rect": {
      "x": 144,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 32,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 15,
       "frameIndex": 20,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "92:1374",
   "groupIndex": 1,
   "title": "Menú barra",
   "image": "menú-barra.jpg",
   "index": 16,
   "width": 239,
   "height": 503,
   "x": 3671,
   "y": -91,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 9,
      "y": 100,
      "width": 222,
      "height": 40
     },
     "index": 33,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 16,
       "frameIndex": 27,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 9,
      "y": 418,
      "width": 222,
      "height": 40
     },
     "index": 34,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 16,
       "frameIndex": 17,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 9,
      "y": 157,
      "width": 222,
      "height": 40
     },
     "index": 35,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 16,
       "frameIndex": 25,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 9,
      "y": 234,
      "width": 222,
      "height": 40
     },
     "index": 36,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 16,
       "frameIndex": 28,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 9,
      "y": 288,
      "width": 222,
      "height": 40
     },
     "index": 37,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 16,
       "frameIndex": 31,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Menú barra",
     "rect": {
      "x": 0,
      "y": 0,
      "width": 239,
      "height": 503
     },
     "index": 38,
     "reactions": [
      {
       "action": "BACK",
       "srcPageIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "104:520",
   "groupIndex": 1,
   "title": "AVISO",
   "image": "aviso.jpg",
   "index": 17,
   "width": 239,
   "height": 200,
   "x": 3671,
   "y": 486,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 9,
      "y": 84,
      "width": 222,
      "height": 40
     },
     "index": 39,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 17,
       "frameIndex": 9,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 9,
      "y": 139,
      "width": 222,
      "height": 40
     },
     "index": 40,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 17,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "104:3712",
   "groupIndex": 1,
   "title": "DETALLES RECETA",
   "image": "detalles-receta.jpg",
   "index": 18,
   "width": 270,
   "height": 591,
   "x": 3791,
   "y": 1501,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 41,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 18,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 42,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 18,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 43,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 18,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 44,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 18,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 153,
      "y": 481,
      "width": 91,
      "height": 24.759037017822266
     },
     "index": 45,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 18,
       "frameIndex": 22,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "126:1009",
   "groupIndex": 1,
   "title": "Tipos-cursos",
   "image": "tipos-cursos.jpg",
   "index": 19,
   "width": 234,
   "height": 110,
   "x": 3841,
   "y": 2459,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Tipos-cursos",
     "rect": {
      "x": 0,
      "y": 0,
      "width": 234,
      "height": 110
     },
     "index": 46,
     "reactions": [
      {
       "action": "BACK",
       "srcPageIndex": 19,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "104:3326",
   "groupIndex": 1,
   "title": "RECETAS-GUARDADAS",
   "image": "recetas-guardadas.jpg",
   "index": 20,
   "width": 270,
   "height": 591,
   "x": 3935,
   "y": 839,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 47,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 20,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 48,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 20,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 49,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 20,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 50,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 20,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "explora",
     "rect": {
      "x": 11,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 51,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 20,
       "frameIndex": 15,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "explora",
     "rect": {
      "x": 153,
      "y": 300,
      "width": 91,
      "height": 25
     },
     "index": 52,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 20,
       "frameIndex": 22,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "receta guardada",
     "rect": {
      "x": 9,
      "y": 225,
      "width": 244,
      "height": 112
     },
     "index": 53,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 20,
       "frameIndex": 18,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "98:1399",
   "groupIndex": 1,
   "title": "Administrar-PERFIL",
   "image": "administrar-perfil.jpg",
   "index": 21,
   "width": 270,
   "height": 591,
   "x": 3946,
   "y": -819,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 54,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 21,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "state-layer",
     "rect": {
      "x": 97,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 55,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 21,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 56,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 21,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "120:5223",
   "groupIndex": 1,
   "title": "CALIFICA-RECETA",
   "image": "califica-receta.jpg",
   "index": 22,
   "width": 270,
   "height": 591,
   "x": 4101,
   "y": 1501,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 57,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 22,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 58,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 22,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 59,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 22,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 60,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 22,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 61,
      "y": 447,
      "width": 127,
      "height": 30
     },
     "index": 61,
     "reactions": [
      {
       "action": "BACK",
       "srcPageIndex": 22,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 63,
      "y": 482,
      "width": 127,
      "height": 30
     },
     "index": 62,
     "reactions": [
      {
       "action": "BACK",
       "srcPageIndex": 22,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "126:1054",
   "groupIndex": 1,
   "title": "MIS-CURSOS",
   "image": "mis-cursos.jpg",
   "index": 23,
   "width": 270,
   "height": 591,
   "x": 4116,
   "y": 2204,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 63,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 23,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 64,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 23,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 65,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 23,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 66,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 23,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 19,
      "y": 350,
      "width": 74,
      "height": 32
     },
     "index": 67,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 23,
       "frameIndex": 26,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 180,
      "y": 354,
      "width": 62,
      "height": 24
     },
     "index": 68,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 23,
       "frameIndex": 24,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 11,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 69,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 23,
       "frameIndex": 14,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "129:1402",
   "groupIndex": 1,
   "title": "CALIFICA-CURSO",
   "image": "califica-curso.jpg",
   "index": 24,
   "width": 270,
   "height": 591,
   "x": 4116,
   "y": 2907,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 70,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 24,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 71,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 24,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 72,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 24,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 73,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 24,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 61,
      "y": 447,
      "width": 127,
      "height": 30
     },
     "index": 74,
     "reactions": [
      {
       "action": "BACK",
       "srcPageIndex": 24,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 63,
      "y": 482,
      "width": 127,
      "height": 30
     },
     "index": 75,
     "reactions": [
      {
       "action": "BACK",
       "srcPageIndex": 24,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "101:153",
   "groupIndex": 1,
   "title": "CONFIG",
   "image": "config.jpg",
   "index": 25,
   "width": 270,
   "height": 591,
   "x": 4317,
   "y": -819,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 76,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 25,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 77,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 25,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 78,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 25,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 79,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 25,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "126:1382",
   "groupIndex": 1,
   "title": "DETALLES-CURSO",
   "image": "detalles-curso.jpg",
   "index": 26,
   "width": 270,
   "height": 591,
   "x": 4426,
   "y": 2204,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 175,
      "y": 176,
      "width": 74,
      "height": 32
     },
     "index": 80,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 26,
       "frameIndex": 29,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 81,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 26,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 82,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 26,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 83,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 26,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 84,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 26,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "explora",
     "rect": {
      "x": 11,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 85,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 26,
       "frameIndex": 14,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "120:5687",
   "groupIndex": 1,
   "title": "PERFIL",
   "image": "perfil.jpg",
   "index": 27,
   "width": 270,
   "height": 591,
   "x": 4465,
   "y": 161,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 86,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 27,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 87,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 27,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 88,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 27,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 355,
      "width": 234,
      "height": 40
     },
     "index": 89,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 27,
       "frameIndex": 21,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 451,
      "width": 234,
      "height": 40
     },
     "index": 90,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 27,
       "frameIndex": 32,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 19,
      "y": 403,
      "width": 234,
      "height": 40
     },
     "index": 91,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 27,
       "frameIndex": 30,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 92,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 27,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "104:411",
   "groupIndex": 1,
   "title": "AYUDA",
   "image": "ayuda.jpg",
   "index": 28,
   "width": 270,
   "height": 591,
   "x": 4627,
   "y": -819,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 93,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 28,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 94,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 28,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 95,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 28,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 96,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 28,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "129:543",
   "groupIndex": 1,
   "title": "PARTICIPA-CURSO",
   "image": "participa-curso.jpg",
   "index": 29,
   "width": 270,
   "height": 591,
   "x": 4736,
   "y": 2204,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 175,
      "y": 176,
      "width": 74,
      "height": 32
     },
     "index": 97,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 29,
       "frameIndex": 26,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 98,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 29,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 99,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 29,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 534,
      "width": 75,
      "height": 40
     },
     "index": 100,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 29,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 101,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 29,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "guardadas",
     "rect": {
      "x": 144,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 102,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 29,
       "frameIndex": 23,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 11,
      "y": 95,
      "width": 98,
      "height": 46
     },
     "index": 103,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 29,
       "frameIndex": 14,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "129:1106",
   "groupIndex": 1,
   "title": "HISTORIAL",
   "image": "historial.jpg",
   "index": 30,
   "width": 270,
   "height": 591,
   "x": 4829,
   "y": 161,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 104,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 30,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 105,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 30,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 106,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 30,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 107,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 30,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "explora",
     "rect": {
      "x": 153,
      "y": 244,
      "width": 91,
      "height": 25
     },
     "index": 108,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 30,
       "frameIndex": 22,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178.47265625,
      "y": 424,
      "width": 63.29706954956055,
      "height": 24
     },
     "index": 109,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 30,
       "frameIndex": 24,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "104:465",
   "groupIndex": 1,
   "title": "SOBRE NOSOTROS",
   "image": "sobre-nosotros.jpg",
   "index": 31,
   "width": 270,
   "height": 591,
   "x": 4937,
   "y": -819,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 110,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 31,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 111,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 31,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 112,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 31,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 113,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 31,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 114,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 31,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 115,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 31,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  },
  {
   "id": "129:1673",
   "groupIndex": 1,
   "title": "CALIFICACIONES",
   "image": "calificaciones.jpg",
   "index": 32,
   "width": 270,
   "height": 591,
   "x": 5139,
   "y": 161,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Button",
     "rect": {
      "x": 16,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 116,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 32,
       "frameIndex": 11,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 97,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 117,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 32,
       "frameIndex": 13,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "Button",
     "rect": {
      "x": 178,
      "y": 527,
      "width": 75,
      "height": 40
     },
     "index": 118,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 32,
       "frameIndex": 12,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    },
    {
     "name": "boton_desplegable",
     "rect": {
      "x": 207,
      "y": 35,
      "width": 35,
      "height": 28
     },
     "index": 119,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 32,
       "frameIndex": 16,
       "transAnimType": 0,
       "transAnimDuration": 300
      }
     ]
    }
   ],
   "layout": null,
   "tmpSolitBackground": false
  }
 ],
 "totalImages": 33,
 "groups": [
  {
   "id": "0:1",
   "index": 0,
   "name": "Wireframes",
   "backColor": "#1E1E1E"
  },
  {
   "id": "63:2",
   "index": 1,
   "name": "Layout HI-FI",
   "backColor": "#1E1E1E"
  }
 ]
}